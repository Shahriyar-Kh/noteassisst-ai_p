// D:\Django Projects\NoteAssist_AI\NoteAssist_AI_frontend\postcss.config.js
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}